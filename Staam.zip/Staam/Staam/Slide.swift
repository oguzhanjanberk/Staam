//
//  Slide.swift
//  Staam
//
//  Created by Oguzhan Janberk on 18/02/2020.
//  Copyright © 2020 Oguzhan Janberk. All rights reserved.
//

import UIKit

class Slide: UIView {

    
    
    @IBOutlet weak var imageView: UIImageView!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
