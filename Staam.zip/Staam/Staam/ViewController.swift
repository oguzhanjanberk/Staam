//
//  ViewController.swift
//  Staam
//
//  Created by Oguzhan Janberk on 30/12/2019.
//  Copyright © 2019 Oguzhan Janberk. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

  
    var musicEffect: AVAudioPlayer = AVAudioPlayer()
    var musicEffectTwo: AVAudioPlayer = AVAudioPlayer()
    var musicEffectThree: AVAudioPlayer = AVAudioPlayer()
    var musicEffectFour: AVAudioPlayer = AVAudioPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let musicFile = Bundle.main.path(forResource: "rain-sound", ofType: ".mp3")
        
        do {
            try musicEffect = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFile!))
            
            musicEffect.pause()
            
        }
        
        catch {
            print(error)
        }
        
       let musicFileTwo = Bundle.main.path(forResource: "waterfall-sound", ofType: ".mp3")
       
       do {
           try musicEffectTwo = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFileTwo!))
           
           musicEffectTwo.pause()
           
       }
       
       catch {
           print(error)
       }
        
        
        let musicFileThree = Bundle.main.path(forResource: "birds-sound", ofType: ".mp3")
        
        do {
            try musicEffectThree = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFileThree!))
            
            musicEffectThree.pause()
            
        }
        
        catch {
            print(error)
        }
        
        
        let musicFileFour = Bundle.main.path(forResource: "wind-sound", ofType: ".mp3")
        
        do {
            try musicEffectFour = AVAudioPlayer(contentsOf: URL (fileURLWithPath: musicFileFour!))
            
            musicEffectFour.pause()
            
        }
        
        catch {
            print(error)
        }
}
    
   
    @IBAction func playMusic(_ sender: Any) {
        musicEffect.play()
    }
    
    @IBAction func pauseMusic(_ sender: Any) {
        musicEffect.pause()
        musicEffectTwo.pause()
        musicEffectThree.pause()
        musicEffectFour.pause()
    }
    
    
    @IBAction func playMusic2(_ sender: Any) {
        musicEffectTwo.play()
    }
    
    
    @IBAction func pauseMusic2(_ sender: Any) {
        musicEffect.pause()
        musicEffectTwo.pause()
        musicEffectThree.pause()
        musicEffectFour.pause()

    }
    
    
    @IBAction func playMusic3(_ sender: Any) {
        musicEffectThree.play()
    }
    
    
    @IBAction func pauseMusic3(_ sender: Any) {
        musicEffect.pause()
        musicEffectTwo.pause()
        musicEffectThree.pause()
        musicEffectFour.pause()
    }
    
    
    @IBAction func playMusic4(_ sender: Any) {
        musicEffectFour.play()
    }
    
    @IBAction func pauseMusic4(_ sender: Any) {
        musicEffect.pause()
        musicEffectTwo.pause()
        musicEffectThree.pause()
        musicEffectFour.pause()
    }
    
}


